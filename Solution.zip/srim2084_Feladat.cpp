#include <iostream>
#include "kirandulas.h"
#include "HasitoTabla.h"
/*


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    CSAPATEPITES    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Lasd Feladat-Megfogalmazasa.docx

*/
int main()
{
    
    Kirandulas tomb("csapatepites3.in");
    int E = tomb.Szamol();
    std::ofstream fout("csapatepites3.out");
    tomb.Print(E ,fout);
    return 0;
}
