#ifndef HASITOTABLA_H
#define HASITOTABLA_H

#include <iostream>
template<typename T ,typename V>
class HashTable{


	class Node {

		public:
			T key;
			V value;
			Node(T key ,V value) : key(key) ,value(value) {}
	};

	int size;
	int capacity;
	Node** tabla;
	bool *torolt_e;
	bool prim_e(int, bool);
public:
	
	HashTable();						  //Alapertelmezett konstuktor
	HashTable(int);                       //Megadott meretu hasitotabla kosntruktora
	int HashFunction(T);                  //tetszoleges hasito fuggveny
	int HashIndex(T, int);                //meghataroz a hasitotablan belul egy indexet,negyzetes kiprobalas szerint
	bool Insert(T ,V);					  //beszur egy elemet a hasitotablaba
	V Search(T);						  //keres egy elemet a hasitotablaban
	bool Delete(T);						  //torol egy elemet a hasitotablabol
	void Clear();                         //tisztit,mindent vissza allit NULL-ra
	void ReHash();						  //Ujra meretezes,ujra hash-eles
	bool SetKeyValue(T ,V);				  //be allitja egy tetszoleges kulcs erteket
	int sizeofTable() const;              //a tabla merete
	V begin();							  //visszateriti a tablaban levo elso letezo elemet
	V end();							  //visszateriti a tablaban levo utolso letezo elemet
	bool containsKey(T);                  //megtalalhato-e a keresett kulcs a tablaban
	bool isEmpty() const;				  //ellenorzi ha ures a tabla,ha igen igazat terit vissza,ellenkezo esetben hamisat
	bool isFull() const;				  //ellenorzni ha betelt a tabla
	void Print() const;					  //ki irat egy tablat,es annak meretet
	~HashTable();						  //destruktor	

};

template<typename T ,typename V>
HashTable<T ,V>::HashTable() {

	size = 0;
	capacity = 101;
	tabla = new Node* [capacity];
	torolt_e = new bool[capacity] {false};
	for (int i = 0; i < capacity; i++) {
		tabla[i] = new Node(NULL ,NULL);
	}
}
template<typename T, typename V>
HashTable<T, V>::HashTable(int capacity) {

	size = 0;
	this->capacity = capacity;
	tabla = new Node * [capacity];
	torolt_e = new bool[capacity] {false};
	for (int i = 0; i < capacity; i++) {
		tabla[i] = new Node(NULL, NULL);
	}
}
template<typename T ,typename V>
int HashTable<T ,V>::HashFunction(T key) {

	return (key % capacity);
}
template<typename T, typename V>
int HashTable<T, V>::HashIndex(T key, int i) {

	return (HashFunction(key) + (i * i)) % capacity;
}

template<typename T ,typename V>
bool HashTable<T ,V>::Insert(T key ,V value) {

	int j = 0;
	
	do {
		int i = HashIndex(key, j);
		if ((tabla[i]->key == NULL) && (!torolt_e[i])) {

			double loadFactor = (1.0 * size) / capacity;
			if (loadFactor > 0.75) {
				ReHash();
			}
			tabla[i]->key = key;
			tabla[i]->value = value;
			size++;
			return true;
		}
		j++;
	} while (j != capacity);
	//betelt tabla eseten ,hamisat terit vissza
	
	return false;
}
template<typename T, typename V>
V HashTable<T, V>::Search(T key) {

	int j = 0, i;

	do {
		i = HashIndex(key, j);
		if (tabla[i]->key == key) {
			return tabla[i]->value;
		}
		j++;
	} while ((tabla[i]->key != NULL) && (j != capacity));

	//abban az esetben ha nem talalhato a keresett kulcs,NULL-t terit vissza
	return NULL;
}
template<typename T, typename V>
bool HashTable<T, V>::Delete(T key) {


	int j = 0;
	bool torolt = false;
	do {
		int i = HashIndex(key, j);

		if (tabla[i]->key == key) {

			size--;
			tabla[i]->key = NULL;
			tabla[i]->value = NULL;
			torolt_e[i] = true;
			torolt = true;
		}
		j++;

	} while ((j != capacity));
	//ha nem sikerult a torles,NULL-t terit vissza
	if (!torolt) {
		std::cout << "A tabla ures!\n";
		return false;
	}
	return true;
}
template<typename T, typename V>
void HashTable<T, V>::ReHash() {

	//masolatot keszitek a tablamrol valamint a torolt_e nevu boolt tombomrol
	Node** copy;
	bool* torolt_eCopy;
	torolt_eCopy = new bool[capacity] {false};
	copy = new Node * [capacity];

	//megjegyzem az ertekeit a tablanak valamint a bool tombnek
	for (int i = 0; i < capacity; i++) {
		copy[i] = new Node(tabla[i]->key, tabla[i]->value);
		torolt_eCopy[i] = torolt_e[i];
	}

	//felszabaditom a tablam es  a bool tombom, majd ujra meretezem
	delete[] tabla;
	delete[] torolt_e;
	capacity *= 2;
	bool prim = false;
	while (!prim_e(capacity, prim)) {
		capacity++;
	}
	tabla = new Node * [capacity];
	torolt_e = new bool[capacity] {false};
	size = 0;
	for (int i = 0; i < capacity; i++) {
		tabla[i] = new Node(NULL, NULL);
	}

	for (int i = 0; i < capacity / 2; i++) {
		if (copy[i]->key != NULL) {
			Insert(copy[i]->key, copy[i]->value);
		}
	}


	for (int i = 0; i < capacity / 2; i++) {
		torolt_e[i] = torolt_eCopy[i];
	}

	delete[]torolt_eCopy;
	delete[] copy;

}
template<typename T, typename V>
bool HashTable<T, V>::prim_e(int n, bool prim) {


	if (n == 1) {
		prim = false;
	}
	else {
		if (n % 2 == 0) {
			prim = (n == 2);
		}
		else {
			if (n <= 5) {
				prim = true;
			}
			else {
				if ((((n - 1) % 6) != 0) && ((n + 1) % 6 != 0)) {
					prim = false;
				}
				else {
					prim = true;
					int j = 3;
					int gyok = sqrt(n);
					while ((j <= gyok) && prim) {
						if (n % j == 0) {
							prim = false;
						}
						else {
							j += 2;
						}
					}
				}
			}
		}
	}
	return prim;
}
template<typename T, typename V>
bool HashTable<T, V>::containsKey(T key) {

	 int j = 0, i;

    do {
		i = HashIndex(key, j);
		if (tabla[i]->key == key) {
				return true;
		}
		j++;
	} while ((tabla[i]->key != NULL) && (j != capacity));

    //abban az esetben ha nem talalhato a keresett kulcs,NULL-t terit vissza
	return false;
}
template<typename T, typename V>
void HashTable<T, V>::Clear() {

	for (int i = 0; i < capacity; i++) {
		tabla[i]->key = NULL;
		tabla[i]->value = NULL;
	}
	capacity = size = 0;
}
template<typename T, typename V>
bool HashTable<T,V>::SetKeyValue(T key ,V value) {

	int j = 0, i;

	do {
		i = HashIndex(key, j);
		if (tabla[i]->key == key) {
			tabla[i]->value = value;
			//ha sikeresen allitotta be egy kulcs erteket,igazat terit vissza
			return true;
		}
		j++;
	} while ((tabla[i]->key != NULL) && (j != capacity));

	//abban az esetben ha nem talalhato a keresett kulcs,hamisat terit vissza
	return false;

}
template<typename T, typename V>
V HashTable<T,V>::begin(){

	
	for (int i = 0; i < capacity; i++) {

		if (tabla[i]->key != NULL) {
			return tabla[i]->value;
		}
	}
	//abban az esetben ha nem talalhato az elso elem,NULL-t terit vissza
	return NULL;
}
template<typename T, typename V>
V HashTable<T, V>::end() {


	for (int i = capacity - 1; i >= 0; i--) {
		if (tabla[i]->key != NULL) {
			return tabla[i]->value;
		}
	}
	//abban az esetben ha nem talalhato az utolso elem,NULL-t terit vissza
	return NULL;
}
template<typename T ,typename V>
int HashTable<T, V>::sizeofTable() const{

	return size;
}
template<typename T, typename V>
bool HashTable<T, V>::isFull() const {

	return size == capacity;
}
template<typename T, typename V>
bool HashTable<T, V>::isEmpty() const {

	return size == 0;
}
template<typename T, typename V>
void HashTable<T, V>::Print() const {

	std::cout <<"A tabla merete: " << size << std::endl;
	for (int i = 0; i < capacity; i++) {
		if (tabla[i]->key != NULL) {
			std::cout << tabla[i]->key << " " << tabla[i]->value << std::endl;
		}
	}
}
template<typename T ,typename V>
HashTable<T ,V>::~HashTable() {

	delete[] tabla;
	size = 0;
	capacity = 0;
}
#endif