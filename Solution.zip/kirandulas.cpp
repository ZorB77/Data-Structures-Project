#include "kirandulas.h"
#include "HasitoTabla.h"
#include <vector>
Kirandulas::Kirandulas(const char* F) {

	std::ifstream f(F);

	f >> n >> S;

	v = new int[n];

	for (int i = 0; i < n; i++) {

		f >> v[i];
	}
	f.close();
}
int Kirandulas::Szamol() {

	int db = 0;
	
	
	for (int i = 0; i < n - 1; i++) {

		for (int j = i + 1; j < n; j++) {

			if (v[i] + v[j] < S) {
				
				db += HT.Search(S - v[i] - v[j]);
				if (!HT.containsKey(S - v[i] - v[j])) {
					HT.Insert(S - v[i] - v[j], NULL);
				}
				
			}
		}
		
		for (int k = 0; k < i; k++) {

			if (v[i] + v[k] < S) {
				if (!HT.containsKey(v[i] + v[k])) {
					HT.Insert(v[i] + v[k], NULL);
				}
				int o = HT.Search(v[i] + v[k]);
				HT.SetKeyValue(v[i] + v[k], o + 1);
				
			}
		}
	}
	return db;
}
void Kirandulas::Print(int E ,std::ofstream &fout) const {

	
	if (!E) {
		std::cout << "Nem sikerult senkinek osszeallitani a ki hirdetett osszeget.\n";
		fout << "Nem sikerult senkinek osszeallitani a ki hirdetett osszeget.\n";
	}
	else {
		std::cout << E << " csapatnak sikerult kigyujteni a kivant osszeget.Gratulalunk nekik!\n";
		fout << E << " csapatnak sikerult kigyujteni a kivant osszeget.Gratulalunk nekik!\n";
	}
}
Kirandulas::~Kirandulas() {

	delete[] v;
}