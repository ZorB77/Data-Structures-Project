#ifndef KIRANDULAS_H_
#define KIRANDULAS_H_

#include <fstream>
#include "HasitoTabla.h"

class Kirandulas {


	int n;
	int S;
	int* v;
	
public:
	HashTable<int, int> HT;
	Kirandulas(const char*);
	int Szamol();
	void Print(int ,std::ofstream&) const;
	~Kirandulas();
};


#endif